<?php
$conn = mysqli_connect( 'localhost', 'root', '', 'btl_cv');
if($conn === false){
    die("Lỗi kết nối" . mysqli_connect_error());
}
?>