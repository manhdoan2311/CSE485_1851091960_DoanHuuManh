<?php
session_start();
ob_start();
include('connect.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Xu ly dang nhap</title>
</head>

<body>
<?php
	$username = "";
	$password = "";
	if(isset($_POST['button']))
	{
		if($_POST['username'] == NULL)
		{
			echo "Bạn chưa nhập tên đăng nhập,mời bạn nhập lại!!!<br />";
		}
		else
		{
			$username = $_POST['username'];
		}
		if($_POST['password'] == NULL)
		{
			echo "Bạn chưa nhập Mật khẩu, mời bạn nhập lại!!!<br />";
		}
		else
		{
			$password = $_POST['password'];
		}
		$SQL = "select * from admin where username = '".$username."' and password = '".$password."'" ;
		$stmt = $connect->prepare($SQL);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$stmt->execute();
		$resultSet=$stmt->fetchAll();
		if($stmt->rowCount() == 0)
		{
			echo "<script> alert('Tài khoản hoặc mật khẩu không đúng!!!'); history.go(-1);</script>";
		}
		else{
			
				header("location:index.php");
			}
		
	}
?>
</body>
</html>