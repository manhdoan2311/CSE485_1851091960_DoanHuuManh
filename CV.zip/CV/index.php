<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DevFolio Bootstrap Portfolio Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: DevFolio - v2.4.0
  * Template URL: https://bootstrapmade.com/devfolio-bootstrap-portfolio-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body id="page-top">

  <!-- ======= Header/ Navbar ======= -->
  <nav class="navbar navbar-b navbar-trans navbar-expand-md fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll" href="#page-top">CV Of Me</a>
      <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="navbar-collapse collapse justify-content-end" id="navbarDefault">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link js-scroll active" href="index.php">Trang Chủ</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#about">Cá Nhân</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#service">Kĩ Năng</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#service1">Kinh Nghiệm</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#contact">Liên Hệ</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="admin.php">Admin</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- ======= Intro Section ======= -->
  <div id="home" class="intro route bg-image" style="background-image: url(assets/img/BACKGRO.jpg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4">Đoàn Hữu Mạnh</h1>
          <p class="intro-subtitle"><span class="text-slider-items">Digital Marketting,Web Design, Photoshop</span><strong class="text-slider"></strong></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div><!-- End Intro Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="box-shadow-full">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-sm-6 col-md-5">
                      <div class="about-img">
                        <img src="assets/img/AVT.jpg" class="img-fluid rounded b-shadow-a" alt="">
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-7">
                    <?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT hovaten, diachi, email,dienthoai,sothich FROM thongtincanhan WHERE id='2'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "-Họ và Tên: " . $row["hovaten"]."<br>";
                            echo "-Địa Chỉ: " . $row["diachi"]."<br>";
                            echo "-Email: " . $row["email"]."<br>";
                            echo "-Điện Thoại " . $row["dienthoai"]."<br>";
                            echo "-Sở Thích : " . $row["sothich"]."<br>";
                        }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
                     
                    </div>
                  </div>
                  <div class="skill-mf">
                    <p class="title-s">Kĩ Năng</p> 

                    <span>HTML</span> <span class="pull-right">15%</span>
                    <div class="progress">
                      <div class="progress-bar" role="progressbar" style="width: 15%;" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <span>CSS3</span> <span class="pull-right">5%</span>
                    <div class="progress">
                      <div class="progress-bar" role="progressbar" style="width: 5%" aria-valuenow="5" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <span>PHP</span> <span class="pull-right">10%</span>
                    <div class="progress">
                      <div class="progress-bar" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <span>JAVASCRIPT</span> <span class="pull-right">10%</span>
                    <div class="progress">
                      <div class="progress-bar" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="about-me pt-4 pt-md-0">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        Thông tin cá nhân
                      </h5>
                    </div>
                    
                    <p class="lead"><?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT * FROM hocvan WHERE id='1'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "-Tên Trường: " . $row["tentruong"]."<br>";
                            echo "-Tên Lớp: " . $row["tenlop"]."<br>";
                            echo "-Ngày Vào: " . $row["ngayvao"]."<br>";
                            echo "-Ngày Ra: " . $row["ngayra"]."<br>";
                            echo "-Ghi Chú: " . $row["ghichu"]."<br>";
                        }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
           
                    </p>
                    <hr />
                    <p class="lead">
                    <?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT * FROM hocvan WHERE id='2'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                          echo "-Tên Trường: " . $row["tentruong"]."<br>";
                          echo "-Tên Lớp: " . $row["tenlop"]."<br>";
                          echo "-Ngày Vào: " . $row["ngayvao"]."<br>";
                          echo "-Ngày Ra: " . $row["ngayra"]."<br>";
                          echo "-Ghi Chú: " . $row["ghichu"]."<br>";
                      }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
                     
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <section id="service" class="services-mf pt-5 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                Kĩ Năng
              </h3>
              <p class="subtitle-a">
                Một số kĩ năng tôi sở hữu trong công việc
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="service-box">
              <div class="service-ico">
                <span class="ico-circle"><i class="ion-monitor"></i></span>
              </div>
              <div class="service-content">
                <h2 class="s-title">Web Design</h2>
                <p class="s-description text-center"></p>
                <?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT tenkynang FROM kynang WHERE id='1'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "- " . $row["tenkynang"]."<br>";

                        }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
                  
                </p>
              </div>
            </div>
          </div>
         
          <div class="col-md-4">
            <div class="service-box">
              <div class="service-ico">
                <span class="ico-circle"><i class="ion-camera"></i></span>
              </div>
              <div class="service-content">
                <h2 class="s-title">Photoshop</h2>
                <p class="s-description text-center">
                
                <?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT tenkynang FROM kynang WHERE id='2'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "- " . $row["tenkynang"]."<br>";
                          
                        }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
                </p>
              </div>
            </div>
          </div>
         
          
          <div class="col-md-4">
            <div class="service-box">
              <div class="service-ico">
                <span class="ico-circle"><i class="ion-stats-bars"></i></span>
              </div>
              <div class="service-content">
                <h2 class="s-title">Digital Marketing</h2>
                <p class="s-description text-center">
                <?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT tenkynang FROM kynang WHERE id='3'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "- " . $row["tenkynang"]."<br>";
                    
                        }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
                
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Services Section -->

    <!-- ======= Counter Section ======= -->
    <section id="service1" class="services-mf pt-5 route">
    <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                KINH NGHIỆM LÀM VIỆC
              </h3>
              <p class="subtitle-a">
                Một số kinh nghiệm của tôi trong công việc
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
    <div class="section-counter paralax-mf bg-image" style="background-image: url(assets/img/counters-bg.jpg)">
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="ion-checkmark-round"></i></span>
              </div>
              <div class="counter-num">
                <p class="counter">5</p>
                <span class="counter-text">DỰ ÁN</span>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="ion-ios-calendar-outline"></i></span>
              </div>
              <div class="counter-num">
                <p class="counter">2</p>
                <span class="counter-text">NĂM KINH NGHIỆM</span>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="ion-ios-people"></i></span>
              </div>
              <div class="counter-num">
                <p class="counter">100</p>
                <span class="counter-text">KHÁCH HÀNG</span>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="ion-ribbon-a"></i></span>
              </div>
              <div class="counter-num">
                <p class="counter">4</p>
                <span class="counter-text">GIẢI THƯỞNG</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Counter Section -->

    <!-- ======= Portfolio Section ======= -->
   

    <!-- ======= Testimonials Section ======= -->
    <div class="testimonials paralax-mf bg-image" style="background-image: url(assets/img/overlay-bg.jpg)">
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-6">
          <div class="author-test">
                  <img src="assets/img/web.jpg" alt="" class="rounded-circle b-shadow-a"  style="margin-left: 150px; width: 250px; height: 200px;">
          </div>
          <div class="content-test">
                  <p class="description lead" style="font-size: 25px; color: white; margin-top: 20px;">
                    <?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT * FROM kinhnghiemlamviec WHERE id='1'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "-Công Việc: " . $row["congviec"]."<br>";
                            echo "-Ngày Làm Việc: " . $row["ngaylamviec"]."<br>";
                            echo "-Ghi Chú: " . $row["ghichu"]."<br>";
                        }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
                  </p>
          </div>
          </div>
          <div class="col-md-6">
          <div class="author-test">
                  <img src="assets/img/maketting.jpg" alt="" class="rounded-circle b-shadow-a" style="margin-left: 150px; width: 250px; height: 200px;">
          </div>
          <div class="content-test">
                  <p class="description lead" style="font-size:25px; color: white; margin-top: 20px;">
                    <?php
                    // Include config file
                    require_once "connect.php";
                    // Attempt select query execution
                    $sql = "SELECT * FROM kinhnghiemlamviec WHERE id='2'";
                    $result = mysqli_query($conn, $sql);
                     
                    if (mysqli_num_rows($result) > 0) {
                        // hiển thị dữ liệu trên trang
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "-Công Việc: " . $row["congviec"]."<br>";
                            echo "-Ngày Làm Việc: " . $row["ngaylamviec"]."<br>";
                            echo "-Ghi Chú: " . $row["ghichu"]."<br>";
                        }
                    } else {
                        echo "0 results";
                    }
                     
                   
                    ?>
                  </p>
          </div>
          </div>
        </div>
    </div>
                  </section>
  <!-- End Testimonials Section -->

   

    <!-- ======= Contact Section ======= -->
    <section class="paralax-mf footer-paralax bg-image sect-mt4 route" style="background-image: url(assets/img/overlay-bg.jpg)">
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="contact-mf">
              <div id="contact" class="box-shadow-full">
                <div class="row">
                  <div class="col-md-6">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        Gửi Mail Cho Tôi
                      </h5>
                    </div>
                    <div>
                      <form action="forms/contact.php" method="post" role="form" class="php-email-form">
                        <div class="row">
                          <div class="col-md-12 mb-3">
                            <div class="form-group">
                              <input type="text" name="name" class="form-control" id="name" placeholder="Điền Tên" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                              <div class="validate"></div>
                            </div>
                          </div>
                          <div class="col-md-12 mb-3">
                            <div class="form-group">
                              <input type="email" class="form-control" name="email" id="email" placeholder="Điền Mail" data-rule="email" data-msg="Please enter a valid email" />
                              <div class="validate"></div>
                            </div>
                          </div>
                          <div class="col-md-12 mb-3">
                            <div class="form-group">
                              <input type="text" class="form-control" name="subject" id="subject" placeholder="" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                              <div class="validate"></div>
                            </div>
                          </div>
                          <div class="col-md-12">
                            <div class="form-group">
                              <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Hãy Viết Gì Đó Gửi Cho Tôi" placeholder="Message"></textarea>
                              <div class="validate"></div>
                            </div>
                          </div>
                          <div class="col-md-12 text-center mb-3">
                            <div class="loading">Đang Tải</div>
                            <div class="error-message"></div>
                            <div class="sent-message">Tin Nhắn Đã Được Gửi, Cảm Ơn!</div>
                          </div>
                          <div class="col-md-12 text-center">
                            <button type="submit" class="button button-a button-big button-rouded">Gửi Tin Nhắn</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="title-box-2 pt-4 pt-md-0">
                      <h5 class="title-left">
                        Liên Lạc Cho Tôi
                      </h5>
                    </div>
                    <div class="more-info">
                      <p class="lead">
                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.451549145644!2d105.80783491475513!3d21.014610986006048!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab61734373a5%3A0xdada778a9ecc675d!2zNTMgVsWpIE5n4buNYyBQaGFuLCBMw6FuZyBI4bqhLCDEkOG7kW5nIMSQYSwgSMOgIE7hu5lpLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1610810528569!5m2!1svi!2s" width="450" height="330" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                      </p>
                      <ul class="list-ico">
                        <li><span class="ion-ios-location"></span> 53 Vũ Ngọc Phan, Láng Hạ, Đống Đa, Hà Nội</li>
                        <li><span class="ion-ios-telephone"></span> 091591411</li>
                        <li><span class="ion-email"></span> doanhuumanh23112000@gmail.com</li>
                      </ul>
                    </div>
                    <div class="socials">
                      <ul>
                        <li><a href="https://www.facebook.com/manhstrong123"><span class="ico-circle"><i class="ion-social-facebook"></i></span></a></li>
                        <li><a href=""><span class="ico-circle"><i class="ion-social-instagram"></i></span></a></li>
                        <li><a href=""><span class="ico-circle"><i class="ion-social-twitter"></i></span></a></li>
                       
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="copyright-box">
            <p class="copyright">&copy; Copyright <strong>DevFolio</strong>. All Rights Reserved</p>
            <div class="credits">
              <!--
              All the links in the footer should remain intact.
              You can delete the links only if you purchased the pro version.
              Licensing information: https://bootstrapmade.com/license/
              Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=DevFolio
            -->
              Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/jquery.counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>