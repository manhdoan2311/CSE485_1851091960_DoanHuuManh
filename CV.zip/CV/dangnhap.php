<?php
session_start();
ob_start();
include("connect.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Form đăng nhập</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="style/styleform.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<title>...::: Đăng nhập :::...</title>
<script language="javascript">
	function ktdangnhap(){
        
        var username = "" , password = "" ;
			username = document.getElementById('username').value;
			password = document.getElementById('password').value;
			if(username == ""){
				alert("nhập tài khoản");
				return false;
			}
			if(password == ""){
				alert("nhập mật khẩu");
				return false;
			}
	}
</script>
</head>

<body>
<?php
	$username = "";
	$password = "";
	if(isset($_POST["username"]))
		$username = $_POST["username"];
	if(isset($_POST["password"]))
		$password = $_POST["password"];
	$_SESSION["username"] = $username;
	$_SESSION["password"] = $password;
	if ($username == "manhdoan" && $password == "123456"){
		header("location: index.php");
		return false;
	}
?>
<div class="container-fluid bg">
	<div class="row justify-content-center">
    	<div class="col-md-3 col-sm-6 col-xs-12 row-container">
			<form name="dangnhap" method="post" action="" onSubmit="return ktradangnhap();">
            	<table width="400" border="0" align="center" style="font-size: 20px; background-color: #ccc,border-radius: 5px; width:400px, height: 300px; padding:20px 20px 20px 20px;" cellpadding="5px">
            	<h1>Đăng Nhập CV</h1>
                <div class="form-group">
                	<label>Tài khoản</label><br />
                    <input type="text" class="form-control" name="username" id="username" placeholder="Nhập tài khoản">
                </div>
                <div class="form-group">
                	<label class="label">Mật khẩu</label><br />
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                </div>
                <div class="form-check">
                	<input type="checkbox" class="form-check-input" id="rememberMe">
                    <label class="form-check-label" for="rememberMe">Ghi nhớ</label>
                </div>
                <button type="submit" class="btn btn-success btn-block">Đăng nhập</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>




