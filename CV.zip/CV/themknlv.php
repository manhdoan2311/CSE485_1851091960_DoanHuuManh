<?php
// Include config file
require_once "connect.php";
 
// Define variables and initialize with empty values
$congviec = $ngaylamviec = $ghichu =  "";
$congviec_err  = $ngaylamviec_err = $ghichu_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
   
    $input_congviec = trim($_POST["congviec"]);
    if(empty($input_congviec)){
        $congviec_err = "Vui lòng nhập tên công việc.";
    } else{
        $congviec = $input_congviec;
    }

    $input_ngaylamviec = trim($_POST["ngaylamviec"]);
    if(empty($input_ngaylamviec)){
        $ngaylamviec_err = "Vui lòng nhập ngày làm việc.";     
    } else{
        $ngaylamviec = $input_ngaylamviec;
    }

    
    $input_ghichu = trim($_POST["ghichu"]);
    if(empty($input_ghichu)){
        $ghichu_err = "Vui lòng nhập ghi chú";     
    } else{
        $ghichu = $input_ghichu;
    }

   
    // Check input errors before inserting in database
    if(empty($congviec_err) && empty($ngaylamviec_err) && empty($ghichu_err) ){
        // Prepare an insert statement
        $sql = "INSERT INTO kinhnghiemlamviec (congviec, ngaylamviec, ghichu) VALUES (?,?,?,?,?)";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssss", $param_congviec, $param_ngaylamviec, $param_ghichu);
            
            // Set parameters
            $param_congviec = $congviec;
            $param_ngaylamviec = $ngaylamviec;
            $param_ghichu = $ghichu;
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: admin.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            //mysqli_stmt_close($stmt);
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($conn);
}
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Thêm</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
        <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
        </style>
    </head>

    <body>
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-header">
                            <h2>Thêm thông tin</h2>
                        </div>
                        <p>Vui lòng điền đầy đủ thông tin.</p>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                                <label>Công Việc</label>
                                <input type="text" name="congviec" class="form-control" value="<?php echo $congviec; ?>">
                                <span class="help-block"><?php echo $congviec_err;?></span>
                            </div>
                            
                            <div class="form-group <?php echo (!empty($ngaylamviec_err)) ? 'has-error' : ''; ?>">
                                <label>Ngày Làm Việc</label>
                                <input type="text" name="ngaylamviec" class="form-control" value="<?php echo $ngaylamviec; ?>">
                                <span class="help-block"><?php echo $ngaylamviec_err;?></span>
                            </div>
                           
                            <div class="form-group <?php echo (!empty($ghichu_err)) ? 'has-error' : ''; ?>">
                                <label>Ghi Chú</label>
                                <input type="text" name="ghichu" class="form-control" value="<?php echo $ghichu; ?>">
                                <span class="help-block"><?php echo $ghichu_err;?></span>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Thêm">
                            <a href="admin.php" class="btn btn-default">Đóng</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>