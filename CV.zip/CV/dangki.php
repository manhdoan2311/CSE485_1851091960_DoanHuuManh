<?php 
session_start();
ob_start();
include('connect.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Thêm admin</title>

<link rel="stylesheet" type="text/css" href="style/styleform.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript">
	function KiemtranhapDL(){
		var username=document.getElementById("txt_username").value;
		var password=document.getElementById("txt_password").value;
		var nhaplaimk=document.getElementById("txt_xnpassword").value;
		
			if(username == ""){
				alert("Họ tên không được để trống! Nhập lại");
				return false;
			}
			
			if(password == ""){
				alert("Mật khẩu không được để trống! Nhập lại");
				return false;
			}
			if(password.length<6){
				alert("Mật khẩu phải lớn hơn 6 ký tự! Nhập lại");
				return false;
			}
			if(xnpassword != password){
				alert("Nhập lại mật khẩu và Mật khẩu phải giống nhau! Nhập lại");
				return false;
			}
			
			
			alert ("tất cả dữ liệu bạn nhập đều hợp lệ. Cảm ơn bạn!")
			return true;
	}
</script>
</head>

<body>

<div class="container-fluid">
	
    <!-- Menu giữa -->
    <!-- Hết menu giữa -->
    <!-- Body -->
    <div class="row">
    	<div class="col-lg-12" style="text-align:left; color:black">
        <?php $ngay=date('Y-m-d'); ?>
        <h2 align="center">THÊM USERS MỚI</h2>
  		
        <?php 
					$Maadmin=isset($_GET['Maadmin'])?$_GET['Maadmin']:0;
					$db="SELECT * FROM admin where Maadmin=$Maadmin";
					$sql_query = mysqli_query($con,$db);
			if($sql_query){
				$row=mysqli_fetch_assoc($con,$db);
		?>
        <form class="form-horizontal" name="themadmin" action="xuly_Themadmin.php" method="post" onSubmit="return KiemtranhapDL()">

        <table width="400" border="0" align="center" style="font-size: 20px; background-color: #ccc,border-radius: 5px; width:400px, height: 300px; padding:20px 20px 20px 20px;" cellpadding="5px">
            	<h1>Đăng Nhập CV</h1>
                <div class="form-group">
                	<label>Tài khoản</label><br />
                    <input type="text" class="form-control" name="username" id="username" placeholder="Nhập tài khoản">
                </div>
                <div class="form-group">
                	<label class="label">Mật khẩu</label><br />
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                </div>
                <div class="form-group">
                	<label class="label">Mật khẩu</label><br />
                    <input type="password" class="form-control" name="xnpassword" id="xnpassword" placeholder="Xác nhận Password">
                </div>
                <button type="submit" class="btn btn-success btn-block">Đăng ký</button>
        </form>
    </div>
    <?php } ?>
</div>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>