<?php
// Include config file
require_once "connect.php";
 
// Define variables and initialize with empty values
$hovaten = $diachi = $email = $dienthoai = $sothich =  "";
$hovaten_err  = $diachi_err = $email_err = $dienthoai_err = $sothich_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_hovaten = trim($_POST["hovaten"]);
    if(empty($input_hovaten)){
        $hovaten_err = "Vui lòng nhập tên.";
    } else{
        $hovaten = $input_hovaten;
    }

    $input_diachi = trim($_POST["diachi"]);
    if(empty($input_diachi)){
        $diachi_err = "Vui lòng nhập giới tính.";     
    } else{
        $diachi = $input_diachi;
    }

    

    // Validate bgroup
    $input_email = trim($_POST["email"]);
    if(empty($input_email)){
        $email_err = "Vui lòng nhập email ";     
    } else{
        $email = $input_email;
    }
    // Validate reg_date
    $input_dienthoai = trim($_POST["dienthoai"]);
    if(empty($input_dienthoai)){
        $dienthoai_err = "Vui lòng nhập số điện thoại";     
    } else{
        $dienthoai = $input_dienthoai;
    }

    $input_sothich = trim($_POST["sothich"]);
    if(empty($input_sothich)){
        $sothich_err = "Vui lòng nhập sở thích";     
    } else{
        $sothich = $input_sothich;
    }

   
    // Check input errors before inserting in database
    if(empty($hovaten_err) && empty($diachi_err) && empty($email_err) && empty($dienthoai_err) && empty($sothich_err) ){
        // Prepare an insert statement
        $sql = "INSERT INTO thongtincanhan (hovaten, diachi, email, dienthoai, sothich) VALUES (?,?,?,?,?)";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssss", $param_hovaten, $param_diachi, $param_email, $param_dienthoai, $param_sothich);
            
            // Set parameters
            $param_hovaten = $hovaten;
            $param_diachi = $diachi;
            $param_email = $email;
            $param_dienthoai = $dienthoai;
            $param_sothich = $sothich;
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: admin.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            //mysqli_stmt_close($stmt);
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($conn);
}
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Thêm</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
        <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
        </style>
    </head>

    <body>
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-header">
                            <h2>Thêm thông tin</h2>
                        </div>
                        <p>Vui lòng điền đầy đủ thông tin.</p>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                                <label>Tên</label>
                                <input type="text" name="hovaten" class="form-control" value="<?php echo $hovaten; ?>">
                                <span class="help-block"><?php echo $hovaten_err;?></span>
                            </div>
                            
                            <div class="form-group <?php echo (!empty($diachi_err)) ? 'has-error' : ''; ?>">
                                <label>Địa Chỉ</label>
                                <input type="text" name="diachi" class="form-control" value="<?php echo $diachi; ?>">
                                <span class="help-block"><?php echo $diachi_err;?></span>
                            </div>
                            <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                                <label>Email</label>
                                <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
                                <span class="help-block"><?php echo $email_err;?></span>
                            </div>
                           
                            <div class="form-group <?php echo (!empty($dienthoai_err)) ? 'has-error' : ''; ?>">
                                <label>Số Điện Thoại</label>
                                <input type="text" name="dienthoai" class="form-control" value="<?php echo $dienthoai; ?>">
                                <span class="help-block"><?php echo $dienthoai_err;?></span>
                            </div>
                            <div class="form-group <?php echo (!empty($sothich_err)) ? 'has-error' : ''; ?>">
                                <label>Sở Thích</label>
                                <input type="text" name="sothich" class="form-control" value="<?php echo $sothich; ?>">
                                <span class="help-block"><?php echo $sothich_err;?></span>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Thêm">
                            <a href="admin.php" class="btn btn-default">Đóng</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>